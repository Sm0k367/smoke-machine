# Contributing to Epic Tech AI

Thank you for considering contributing to Epic Tech AI! This document outlines the process for contributing to this project.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please be respectful and considerate of others.

## How Can I Contribute?

### Reporting Bugs

If you find a bug, please create an issue with the following information:

- A clear, descriptive title
- Steps to reproduce the issue
- Expected behavior
- Actual behavior
- Screenshots if applicable
- Any relevant details about your environment

### Suggesting Enhancements

We welcome suggestions for enhancements! Please create an issue with:

- A clear, descriptive title
- A detailed description of the proposed enhancement
- Any relevant examples or mockups
- Why this enhancement would be useful to most users

### Pull Requests

1. Fork the repository
2. Create a new branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Commit your changes (`git commit -m 'Add some amazing feature'`)
5. Push to the branch (`git push origin feature/amazing-feature`)
6. Open a Pull Request

#### Pull Request Guidelines

- Update the README.md with details of changes if applicable
- Update the documentation if necessary
- The PR should work on modern browsers
- Follow the existing code style
- Include appropriate tests if adding new functionality
- Make sure all tests pass

## Development Setup

1. Clone the repository
```bash
git clone https://github.com/yourusername/epic-tech-ai.git
cd epic-tech-ai
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env
```
Then edit the `.env` file with your API keys and configuration.

4. Start the development server
```bash
npm run dev
```

## Style Guide

### JavaScript

- Use ES6+ features
- Use camelCase for variable and function names
- Use PascalCase for class names
- Use meaningful variable and function names
- Add comments for complex logic

### CSS

- Use kebab-case for class names
- Use CSS variables for colors, spacing, etc.
- Follow the existing component structure

### HTML

- Use semantic HTML elements
- Ensure accessibility
- Keep the markup clean and readable

## License

By contributing to Epic Tech AI, you agree that your contributions will be licensed under the project's MIT License.