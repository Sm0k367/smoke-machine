/**
 * Epic Tech AI - Setup Script
 * 
 * This script helps set up the Epic Tech AI Avatar Assistant project.
 * It checks for required dependencies and creates necessary directories.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('\n🤖 Epic Tech AI - Setup Script\n');

// Check if .env file exists, if not create it from example
if (!fs.existsSync(path.join(__dirname, '.env'))) {
  console.log('📝 Creating .env file from example...');
  try {
    if (fs.existsSync(path.join(__dirname, '.env.example'))) {
      fs.copyFileSync(path.join(__dirname, '.env.example'), path.join(__dirname, '.env'));
      console.log('✅ Created .env file. Please edit it with your API keys and configuration.');
    } else {
      console.log('❌ .env.example file not found. Please create a .env file manually.');
    }
  } catch (error) {
    console.error('❌ Error creating .env file:', error.message);
  }
} else {
  console.log('✅ .env file already exists.');
}

// Check if media directory exists, if not create it
const mediaDir = path.join(__dirname, 'media');
if (!fs.existsSync(mediaDir)) {
  console.log('📁 Creating media directory...');
  try {
    fs.mkdirSync(mediaDir, { recursive: true });
    console.log('✅ Created media directory.');
  } catch (error) {
    console.error('❌ Error creating media directory:', error.message);
  }
} else {
  console.log('✅ Media directory already exists.');
}

// Check Node.js version
console.log('🔍 Checking Node.js version...');
try {
  const nodeVersion = process.version;
  console.log(`📊 Node.js version: ${nodeVersion}`);
  
  const versionNumber = nodeVersion.replace('v', '').split('.');
  const majorVersion = parseInt(versionNumber[0], 10);
  
  if (majorVersion < 14) {
    console.warn('⚠️ Warning: This project requires Node.js v14 or higher. Please upgrade your Node.js version.');
  } else {
    console.log('✅ Node.js version is compatible.');
  }
} catch (error) {
  console.error('❌ Error checking Node.js version:', error.message);
}

// Check for required dependencies
console.log('🔍 Checking for required dependencies...');
try {
  console.log('📦 Installing dependencies...');
  execSync('npm install', { stdio: 'inherit' });
  console.log('✅ Dependencies installed successfully.');
} catch (error) {
  console.error('❌ Error installing dependencies:', error.message);
}

console.log('\n🚀 Setup complete! You can now start the server with: npm start\n');